# KMA Tuyển sinh 2026 — Cấu trúc dự án

## Cây thư mục

```
kma_project/
│
├── index.html              ← File chính, mở file này trên trình duyệt
├── style.css               ← Toàn bộ CSS / thiết kế giao diện
├── app.js                  ← Toàn bộ logic JavaScript
│
├── pages/                  ← HTML từng trang (tham khảo / phát triển riêng)
│   ├── home.html           ← Trang chủ
│   ├── user-pages.html     ← Login, Register, Nộp hồ sơ, Dashboard, Kết quả
│   └── admin-chatbot.html  ← Chatbot AI, Admin
│
└── README.md               ← File này
```

## Mô tả từng file

### `index.html`
File chính của ứng dụng. Bao gồm:
- Topbar + Navigation
- Tất cả các trang (SPA - Single Page Application)
- Modals (Xác nhận nhập học, Xuất báo cáo)
- Import `style.css` và `app.js`

**Cách chạy:** Mở `index.html` bằng trình duyệt là chạy được.

### `style.css`
Toàn bộ CSS được chia thành các section có comment rõ ràng:
- Variables (màu sắc, font)
- Top bar, Nav
- Hero, Stats bar
- Sections, Cards
- Phương thức tuyển sinh
- Bảng chỉ tiêu, Tin tức
- Forms (Login, Register, Wizard nộp hồ sơ)
- Dashboard, Timeline
- Kết quả xét tuyển
- Chatbot
- Admin (Tabs, Tables, Summary cards)
- Modal
- Footer
- Responsive

### `app.js`
Logic JavaScript chia thành các nhóm:
- `showPage(id)` — Điều hướng giữa các trang
- `showWizard(n)`, `nextWizard()`, `prevWizard()`, `submitHoSo()` — Wizard nộp hồ sơ
- `fakeUpload()` — Giả lập upload file
- `handleLogin()`, `handleRegister()` — Xác thực người dùng
- `switchAdminTab()`, `approveRow()` — Chức năng Admin
- `botReplies`, `addMsg()`, `sendSug()`, `sendChat()` — Chatbot AI
- `showModal()`, `closeModal()`, `confirmNhapHoc()`, `fakeExport()` — Modals

### `pages/` (Thư mục tham khảo)
Các file HTML tách riêng từng trang, dùng để tham khảo hoặc khi muốn phát triển từng trang độc lập. **Không cần** để chạy ứng dụng — mọi thứ đã có trong `index.html`.

## Các trang chức năng

| Trang | ID | Use case liên quan |
|-------|----|--------------------|
| Trang chủ | `home` | UC4, UC5 — Xem & tra cứu thông tin |
| Đăng nhập | `login` | UC2 — Đăng nhập |
| Đăng ký | `register` | UC1 — Đăng ký tài khoản |
| Nộp hồ sơ | `nophoso` | UC7 — Wizard 4 bước |
| Hồ sơ của tôi | `dashboard` | UC8, UC9 — Chỉnh sửa & theo dõi |
| Kết quả | `ketqua` | UC10, UC11 — Tra cứu & xác nhận |
| Chatbot AI | `chatbot` | UC6 — Hỏi đáp tự động |
| Quản trị | `admin` | UC12–19 — Toàn bộ chức năng Admin |

## Thông tin thực KMA 2026

- **Hotline:** 0986 622 772 (có Zalo)
- **Website:** tuyensinh.actvn.edu.vn
- **Cơ sở HN:** 141 đường Chiến Thắng, Thanh Liệt, TP. Hà Nội
- **Cơ sở HCM:** 17A Cộng Hoà, Tân Sơn Nhất, TP. HCM
- **Tổng chỉ tiêu 2026:** 600 (HN: 520, HCM: 80)
