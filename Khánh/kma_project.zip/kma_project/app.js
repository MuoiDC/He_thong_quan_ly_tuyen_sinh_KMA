/* ============================================================
   KMA Tuyển sinh 2026 — app.js
   ============================================================ */

/* ---- NAVIGATION ---- */
var currentWizard = 2;

function showPage(id) {
  document.querySelectorAll('.page').forEach(function(p) { p.classList.remove('active'); });
  document.querySelectorAll('.nav-link').forEach(function(l) { l.classList.remove('active'); });
  document.getElementById('page-' + id).classList.add('active');
  var map = { home:0, login:1, register:2, nophoso:3, dashboard:4, ketqua:5, chatbot:6, admin:7 };
  var links = document.querySelectorAll('.nav-link');
  if (map[id] !== undefined) links[map[id]].classList.add('active');
  window.scrollTo(0, 0);
}

/* ---- WIZARD (NOP HO SO) ---- */
function showWizard(n) {
  currentWizard = n;
  for (var i = 1; i <= 4; i++) {
    var el = document.getElementById('wizard-' + i);
    if (el) el.style.display = (i === n) ? 'block' : 'none';
  }
  document.querySelectorAll('.wz-step').forEach(function(s, i) {
    s.classList.remove('active', 'done');
    if (i + 1 < n) s.classList.add('done');
    else if (i + 1 === n) s.classList.add('active');
  });
  var btn = document.getElementById('wiz-next-btn');
  if (n === 4) { btn.textContent = 'Nộp hồ sơ →'; btn.onclick = submitHoSo; }
  else { btn.textContent = 'Tiếp theo →'; btn.onclick = nextWizard; }
}

function nextWizard() { if (currentWizard < 4) showWizard(currentWizard + 1); }
function prevWizard() { if (currentWizard > 1) showWizard(currentWizard - 1); }

function submitHoSo() {
  var btn = document.getElementById('wiz-next-btn');
  btn.textContent = 'Đang nộp hồ sơ...'; btn.disabled = true;
  setTimeout(function() {
    btn.textContent = 'Nộp hồ sơ thành công! ✓'; btn.style.background = 'var(--green)';
    setTimeout(function() { showPage('dashboard'); }, 1200);
  }, 1400);
}

/* ---- UPLOAD GIẢ LẬP ---- */
function fakeUpload(el, key) {
  el.style.borderColor = '#a5d6b5'; el.style.background = 'rgba(26,107,60,0.04)';
  el.innerHTML = '<span style="font-size:24px">✓</span><p style="color:var(--green);font-weight:500">Đã chọn file thành công</p>';
  var ind = document.getElementById('up-' + key);
  if (ind) ind.style.display = 'flex';
}

/* ---- AUTH ---- */
function handleLogin() {
  var btn = document.querySelector('#page-login .submit-btn');
  btn.textContent = 'Đang xác thực...'; btn.disabled = true;
  setTimeout(function() {
    btn.textContent = 'Đăng nhập thành công! ✓'; btn.style.background = 'var(--green)';
    setTimeout(function() { showPage('dashboard'); }, 900);
  }, 1000);
}

function handleRegister() {
  var btn = document.querySelector('#page-register .submit-btn');
  btn.textContent = 'Đang xử lý...'; btn.disabled = true;
  setTimeout(function() {
    btn.textContent = 'Đăng ký thành công! ✓'; btn.style.background = 'var(--green)';
    setTimeout(function() { showPage('dashboard'); }, 1000);
  }, 1200);
}

/* ---- ADMIN TABS ---- */
function switchAdminTab(el, tabId) {
  document.querySelectorAll('.admin-tab').forEach(function(t) { t.classList.remove('active'); });
  el.classList.add('active');
  ['tab-hoso','tab-taikhoan','tab-tuyensinh','tab-chatbot','tab-ketqua','tab-baocao'].forEach(function(id) {
    var t = document.getElementById(id);
    if (t) t.style.display = (id === tabId) ? 'block' : 'none';
  });
}

function approveRow(btn, status, label) {
  var row = btn.closest('tr');
  var map = { approved: 'badge-approved', rejected: 'badge-rejected' };
  var badge = row.querySelector('.badge');
  badge.className = 'badge ' + map[status]; badge.textContent = label;
  row.querySelectorAll('.action-btn').forEach(function(a) { a.remove(); });
  var nb = document.createElement('button'); nb.className = 'action-btn'; nb.textContent = 'Xem chi tiết';
  row.querySelector('td:last-child').appendChild(nb);
}

/* ---- CHATBOT ---- */
var botReplies = {
  'Chỉ tiêu từng ngành năm 2026?':
    'Chỉ tiêu tuyển sinh KMA 2026:<br><br>' +
    '📍 <strong>Cơ sở Hà Nội (520 chỉ tiêu)</strong><br>' +
    '• An toàn thông tin (7480202KMA): <strong>240</strong><br>' +
    '• Công nghệ thông tin (7480201KMA): <strong>140</strong><br>' +
    '• Kỹ thuật Điện tử Viễn thông (7520207): <strong>140</strong><br><br>' +
    '📍 <strong>Cơ sở TP.HCM (80 chỉ tiêu)</strong><br>' +
    '• An toàn thông tin (7480202KMP): <strong>80</strong><br><br>' +
    'Tổng: <strong>600 chỉ tiêu</strong>',

  'Tổ hợp môn xét tuyển ngành ATTT?':
    'Ngành An toàn thông tin sử dụng các tổ hợp:<br><br>' +
    '• <strong>A00</strong> — Toán, Vật lý, Hóa học<br>' +
    '• <strong>A01</strong> — Toán, Vật lý, Tiếng Anh<br>' +
    '• <strong>X26</strong> — Toán, Tiếng Anh, Tin học<br>' +
    '• <strong>X06</strong> — Toán, Vật lý, Tin học<br>' +
    '• <strong>K01</strong> — Toán, Văn, Vật lý<br><br>' +
    'Không có chênh lệch điểm giữa các tổ hợp. Hệ số 1 cho tất cả các môn.',

  'Ưu tiên chứng chỉ tiếng Anh như thế nào?':
    'Bảng cộng điểm ưu tiên chứng chỉ tiếng Anh (PT2):<br><br>' +
    '• IELTS 5.5–6.0 / TOEIC 650–749 / TOEFL 65–79 → <strong>+0.5 điểm</strong><br>' +
    '• IELTS 6.5–7.0 / TOEIC 750–849 / TOEFL 80–94 → <strong>+1.0 điểm</strong><br>' +
    '• IELTS ≥7.5 / TOEIC ≥850 / TOEFL ≥95 → <strong>+1.5 điểm</strong><br><br>' +
    'Lưu ý: Không áp dụng cho TOEFL iBT Home Edition.',

  'Địa chỉ và hotline liên hệ?':
    'Thông tin liên hệ KMA:<br><br>' +
    '📍 <strong>Cơ sở HN:</strong> 141 đường Chiến Thắng, phường Thanh Liệt, TP. Hà Nội<br>' +
    '📍 <strong>Cơ sở HCM:</strong> 17A Cộng Hoà, phường Tân Sơn Nhất<br><br>' +
    '📞 <strong>Hotline: 0986 622 772</strong> (có tư vấn Zalo)<br>' +
    '📧 contact@actvn.edu.vn<br>' +
    '🌐 tuyensinh.actvn.edu.vn'
};

function addMsg(text, type) {
  var body = document.getElementById('chat-body');
  var div = document.createElement('div'); div.className = 'msg ' + type;
  var now = new Date();
  div.innerHTML = text + '<div class="msg-time">' + now.getHours() + ':' + String(now.getMinutes()).padStart(2,'0') + '</div>';
  body.appendChild(div); body.scrollTop = body.scrollHeight;
}

function showTyping() {
  var body = document.getElementById('chat-body');
  var t = document.createElement('div'); t.className = 'typing'; t.id = 'typing-indicator';
  t.innerHTML = '<div class="typing-dot"></div><div class="typing-dot"></div><div class="typing-dot"></div>';
  body.appendChild(t); body.scrollTop = body.scrollHeight;
}

function sendSug(text) {
  document.getElementById('sug-row').style.display = 'none';
  addMsg(text, 'user'); showTyping();
  setTimeout(function() {
    var ti = document.getElementById('typing-indicator'); if (ti) ti.remove();
    addMsg(botReplies[text] || 'Cảm ơn câu hỏi! Vui lòng liên hệ hotline <strong>0986 622 772</strong> (có Zalo) để được tư vấn chi tiết.', 'bot');
  }, 1100);
}

function sendChat() {
  var inp = document.getElementById('chat-in'); var val = inp.value.trim(); if (!val) return;
  inp.value = ''; addMsg(val, 'user'); showTyping();
  setTimeout(function() {
    var ti = document.getElementById('typing-indicator'); if (ti) ti.remove();
    var reply = botReplies[val] || 'Tôi ghi nhận câu hỏi về "<em>' + val + '</em>". Vui lòng liên hệ hotline <strong>0986 622 772</strong> hoặc tuyensinh.actvn.edu.vn để được hỗ trợ chi tiết.';
    addMsg(reply, 'bot');
  }, 1200);
}

/* ---- MODALS ---- */
function showModal(id) { document.getElementById(id).classList.add('show'); }
function closeModal(id) { document.getElementById(id).classList.remove('show'); }

function confirmNhapHoc() {
  closeModal('modal-xacnhan'); showPage('dashboard');
  setTimeout(function() {
    var chip = document.querySelector('.status-chip');
    if (chip) { chip.className = 'status-chip status-approved'; chip.textContent = 'Đã xác nhận nhập học ✓'; }
  }, 200);
}

function fakeExport() {
  closeModal('modal-baocao');
  alert('Báo cáo đang được tạo. Hệ thống sẽ thông báo khi hoàn tất (file lưu tạm 24 giờ).');
}

/* ---- CLOSE MODAL KHI CLICK NGOÀI ---- */
document.addEventListener('DOMContentLoaded', function() {
  document.querySelectorAll('.modal-overlay').forEach(function(ov) {
    ov.addEventListener('click', function(e) { if (e.target === ov) ov.classList.remove('show'); });
  });
});
